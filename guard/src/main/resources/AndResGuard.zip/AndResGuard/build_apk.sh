#!/usr/bin/env bash

java -jar AndResGuard-cli-1.2.20-fix.jar app-release.apk -signatureType v2
